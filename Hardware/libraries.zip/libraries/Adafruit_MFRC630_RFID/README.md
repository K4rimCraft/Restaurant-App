# Adafruit MFRC630 RFID Front-End Driver [![Build Status](https://travis-ci.org/adafruit/Adafruit_MFRC630.svg?branch=master)](https://travis-ci.org/adafruit/Adafruit_MFRC630)

Driver for the Adafruit MFRC630 RFID Front-End Breakout Board.
