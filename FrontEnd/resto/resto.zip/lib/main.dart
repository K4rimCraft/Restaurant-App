import 'package:flutter/material.dart';
import 'package:resto/EditMenu/Page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        brightness: Brightness.light,
        fontFamily: 'Kanit',
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        brightness: Brightness.dark,
        fontFamily: 'Kanit',
      ),
      themeMode: ThemeMode.light,
      home: NavBarController(),
    );
  }
}

class NavBarController extends StatefulWidget {
  NavBarController({super.key});
  @override
  State<NavBarController> createState() => _NavBarControllerState();
}

class _NavBarControllerState extends State<NavBarController> {
  int currentPageIndex = 0;
  List<String> records = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: switch (currentPageIndex) {
        0 => EditMenuPage(),
        int() => Container()
      },
      bottomNavigationBar: NavigationBarTheme(
        data: NavigationBarThemeData(
          labelTextStyle: MaterialStateTextStyle.resolveWith(
              (states) => const TextStyle(fontSize: 15)),
        ),
        child: NavigationBar(
          labelBehavior: NavigationDestinationLabelBehavior.onlyShowSelected,
          onDestinationSelected: (index) {
            setState(() {
              currentPageIndex = index;
            });
          },
          indicatorColor: Theme.of(context).dividerColor,
          selectedIndex: currentPageIndex,
          destinations: [
            NavigationDestination(
              icon: Icon(
                Icons.home_filled,
                color:
                    currentPageIndex == 0 ? Colors.grey[100] : Colors.grey[600],
              ),
              label: 'Main',
            ),
            NavigationDestination(
              icon: Icon(
                Icons.restaurant_menu_outlined,
                color:
                    currentPageIndex == 1 ? Colors.grey[100] : Colors.grey[600],
              ),
              label: 'Restaurant',
            ),
            NavigationDestination(
              icon: Icon(
                Icons.list_alt,
                color:
                    currentPageIndex == 2 ? Colors.grey[100] : Colors.grey[600],
              ),
              label: 'Orders',
            ),
          ],
        ),
      ),
    );
  }
}
