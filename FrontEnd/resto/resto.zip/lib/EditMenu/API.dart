import 'package:http/http.dart' as http;
import 'dart:convert';

Future<List<FoodCardData>> fetchFoodCardData() async {
  final response =
      await http.get(Uri.parse('http://localhost:8080/admin/getMenuItems'));

  if (response.statusCode == 200) {
    return FoodCardData.toList(jsonDecode(response.body));
  } else {
    throw Exception('faild to fetch food card data');
  }
}

Future<void> sendFoodCardData(FoodCardData dataObj) async {
  final response = await http.post(
    Uri.parse('http://localhost:8080/admin/addProduct'),
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
    body: jsonEncode(<String, String>{
      'name': dataObj.name,
      'inStock': dataObj.inStock.toString(),
      'description': dataObj.description.toString(),
      'rating': dataObj.rating.toString(),
      'price': dataObj.price.toString(),
      'timesOrdered': dataObj.timesOrdered.toString(),
      'image': dataObj.image,
    }),
  );

  if (response.statusCode == 200) {
  } else {
    throw Exception('faild to send food card data');
  }
}

Future<void> updateFoodCardData(
    FoodCardData dataObj, func(String errMsg)) async {
  final response = await http.put(
    Uri.parse(
        'http://localhost:8080/admin/updateItem/${dataObj.itemId.toString()}'),
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
    body: jsonEncode(<String, String>{
      'name': dataObj.name,
      'inStock': dataObj.inStock.toString(),
      'description': dataObj.description.toString(),
      'rating': dataObj.rating.toString(),
      'price': dataObj.price.toString(),
      'timesOrdered': dataObj.timesOrdered.toString(),
      'image': dataObj.image,
    }),
  );

  if (response.statusCode == 200) {
    func('pop');
  } else if (response.statusCode == 500) {
    func("Duplicate Entry In 'name' Column.\nTry another name!");
  } else {
    throw Exception('faild to update food card data');
  }
}

Future<void> deleteFoodCardData(FoodCardData dataObj) async {
  final response = await http.delete(
    Uri.parse(
        'http://localhost:8080/admin/deleteMenuItem/${dataObj.itemId.toString()}'),
    headers: <String, String>{
      'Content-Type': 'application/json; charset=UTF-8',
    },
  );

  if (response.statusCode == 200) {
  } else {
    throw Exception('faild to delete food card data');
  }
}

class FoodCardData {
  final int itemId;
  final String name;
  final int inStock;
  final String description;
  final double rating;
  final double price;
  final int timesOrdered;
  final String image;

  const FoodCardData({
    required this.itemId,
    required this.name,
    required this.description,
    required this.rating,
    required this.price,
    required this.timesOrdered,
    required this.inStock,
    required this.image,
  });

  static toList(List<dynamic> data) {
    List<FoodCardData> card = [];
    for (int i = 0; i < data.length; i++) {
      try {
        card.add(FoodCardData(
          itemId: data[i]['itemId'],
          name: data[i]['name'],
          description: data[i]['description'],
          rating: data[i]['rating'],
          price: data[i]['price'],
          timesOrdered: data[i]['timesOrdered'],
          inStock: data[i]['inStock'],
          image: '5',
        ));
      } catch (err) {
        print(err);
      }
    }

    return card;
  }

  static FoodCardData emptyObj() {
    return const FoodCardData(
        itemId: 0,
        name: "",
        description: "",
        rating: 0,
        price: 0,
        timesOrdered: 0,
        inStock: 0,
        image: "");
  }
}
