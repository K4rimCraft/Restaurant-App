import 'package:flutter/material.dart';
import 'package:resto/EditMenu/API.dart';
import 'package:flutter/services.dart';

class FoodCard extends StatelessWidget {
  final FoodCardData cardData;
  final Function update;

  const FoodCard({
    required this.cardData,
    required this.update,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 120,
      width: MediaQuery.of(context).size.width,
      //constraints: BoxConstraints.expand(),
      child: Card(
        elevation: 1,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              width: MediaQuery.of(context).size.width / 3,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  const Image(
                    isAntiAlias: true,
                    image: AssetImage('assets/pngwing.com (1).png'),
                  ),
                  Container(
                    color: Theme.of(context).canvasColor,
                    width: 3.5,
                    height: 80,
                  ),
                ],
              ),
            ),
            Container(
              width: MediaQuery.of(context).size.width / 2,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Text(cardData.name, style: const TextStyle(fontSize: 23)),
                  Text(cardData.price.toString(),
                      style:
                          const TextStyle(fontSize: 23, color: Colors.green)),
                  Text(cardData.timesOrdered.toString(),
                      style: const TextStyle(fontSize: 23)),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton.filledTonal(
                          onPressed: () {
                            showModalBottomSheet(
                              isScrollControlled: true,
                              context: context,
                              builder: (BuildContext context) {
                                return EditForm(this.update, cardData, true);
                              },
                            );
                          },
                          icon: Icon(Icons.edit)),
                      IconButton.filledTonal(
                          onPressed: () async {
                            await showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    title: const Text("Confirm"),
                                    content: const Text(
                                        "Are you sure you want to delete this item?\nThis proccess can't be undone."),
                                    actions: <Widget>[
                                      TextButton(
                                        child: const Text('Yes'),
                                        onPressed: () async {
                                          await deleteFoodCardData(cardData);
                                          this.update();
                                          Navigator.of(context).pop();
                                        },
                                      ),
                                      TextButton(
                                        child: const Text('No'),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      ),
                                    ],
                                  );
                                });
                          },
                          icon: Icon(Icons.delete))
                    ],
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MyWidget extends StatefulWidget {
  const MyWidget({super.key});

  @override
  State<MyWidget> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<MyWidget> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

class EditMenuPage extends StatefulWidget {
  const EditMenuPage({super.key});

  @override
  State<EditMenuPage> createState() => _EditMenuPageState();
}

class _EditMenuPageState extends State<EditMenuPage> {
  Future<List<FoodCardData>> foodCardData = fetchFoodCardData();
  final yourScrollController = ScrollController();
  int selectedSeg = 1;

  void update() {
    setState(() {
      foodCardData = fetchFoodCardData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
          child: Column(
            children: [
              const SizedBox(height: 20),
              // SegmentedButton(
              //     segments: const [
              //       ButtonSegment(
              //           value: 1, icon: Icon(Icons.abc), label: Text('Food')),
              //       ButtonSegment(
              //           value: 2, icon: Icon(Icons.abc), label: Text('Drinks'))
              //     ],
              //     selected: {
              //       selectedSeg
              //     },
              //     onSelectionChanged: (index) {
              //       setState(() {
              //         selectedSeg = index.first;
              //       });
              //     }),
              Flexible(
                  child: FutureBuilder(
                      future: foodCardData,
                      builder: (context, foodDataList) {
                        if (foodDataList.hasError) {
                          return Container(
                              alignment: Alignment.center,
                              width: 300,
                              height: 300,
                              child: const Text('Error'));
                        } else if (foodDataList.hasData) {
                          return Scrollbar(
                            controller: yourScrollController,
                            interactive: true,
                            scrollbarOrientation: ScrollbarOrientation.right,
                            child: Container(
                              //constraints: const BoxConstraints(maxWidth: 600),
                              padding: const EdgeInsets.fromLTRB(25, 0, 25, 0),
                              child: ListView.builder(
                                shrinkWrap: true,
                                controller: yourScrollController,
                                scrollDirection: Axis.vertical,
                                itemCount: foodDataList.data!.length,
                                itemBuilder: (context, index) {
                                  return FoodCard(
                                      update: update,
                                      cardData: foodDataList.data![index]);
                                },
                              ),
                            ),
                          );
                        } else {
                          return Container(
                            alignment: Alignment.center,
                            width: 300,
                            height: 300,
                            child: CircularProgressIndicator(),
                          );
                        }
                      })),
            ],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          enableFeedback: true,
          //hoverColor: Colors.blue[300],
          onPressed: () {
            setState(() {
              showModalBottomSheet(
                isScrollControlled: true,
                context: context,
                builder: (BuildContext context) {
                  return EditForm(this.update, FoodCardData.emptyObj(), false);
                },
              );
              //foodTitles.insert(0, 'element');
            });
          },
          label: const Text(
            'Add',
            style: TextStyle(fontFamily: 'OpenSansBold'),
          ),
          icon: const Icon(Icons.add),
        ));
  }
}

class EditForm extends StatefulWidget {
  final bool isEdit;
  final Function updateList;
  final FoodCardData cardData;
  EditForm(this.updateList, this.cardData, this.isEdit);

  @override
  State<EditForm> createState() => _EditFormState();
}

class _EditFormState extends State<EditForm> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController nameControl;
  late TextEditingController descControl;
  late TextEditingController stockControl;
  late TextEditingController priceControl;

  @override
  void initState() {
    super.initState();
    nameControl = TextEditingController();
    descControl = TextEditingController();
    priceControl = TextEditingController();
    stockControl = TextEditingController();
    nameControl.text = widget.cardData.name;
    descControl.text = widget.cardData.description;
    priceControl.text = widget.cardData.price.toString();
    stockControl.text = widget.cardData.timesOrdered.toString();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Form(
        key: _formKey,
        child: Container(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: SizedBox(
            height: 600,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                const SizedBox(height: 15),
                const Divider(
                  thickness: 5,
                  indent: 210,
                  endIndent: 210,
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                    widget.isEdit
                        ? "Edit item properties"
                        : "Add a food item to the menu:",
                    style: TextStyle(fontSize: 22)),
                const SizedBox(
                  height: 15,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    SizedBox(
                      height: 150,
                      width: 150,
                      child: Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                color: Theme.of(context).cardColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30))),
                          ),
                          Image(
                              image: AssetImage('assets/pngwing.com (1).png')),
                          Container(
                            alignment: Alignment.bottomRight,
                            padding: EdgeInsets.all(10),
                            child: IconButton.filledTonal(
                              padding: EdgeInsets.all(10),
                              iconSize: 30,
                              icon: const Icon(Icons.image_search_outlined),
                              onPressed: () {},
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 150,
                      width: 150,
                      child: Stack(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                                color: Theme.of(context).cardColor,
                                borderRadius:
                                    BorderRadius.all(Radius.circular(30))),
                          ),
                          Image(
                              image: AssetImage('assets/pngwing.com (1).png')),
                          Container(
                            alignment: Alignment.bottomRight,
                            padding: EdgeInsets.all(10),
                            child: IconButton.filledTonal(
                              padding: EdgeInsets.all(10),
                              iconSize: 30,
                              icon: const Icon(Icons.image_search_outlined),
                              onPressed: () {},
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Flexible(
                      flex: 2,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(20, 15, 5, 0),
                        child: TextFormField(
                          controller: nameControl,
                          decoration: const InputDecoration(
                              border: OutlineInputBorder(), labelText: 'Name'),
                          validator: (String? value) {
                            return (value == null || value.isEmpty)
                                ? 'Can\'t be empty!'
                                : null;
                          },
                        ),
                      ),
                    ),
                    Flexible(
                      flex: 1,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5, 15, 5, 0),
                        child: TextFormField(
                          //expands: true,
                          controller: priceControl,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Price',
                          ),
                          validator: (String? value) {
                            return (value == null || value.isEmpty)
                                ? 'Can\'t be empty!'
                                : null;
                          },
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.allow(
                                RegExp(r'(^\d*\.?\d*)'))
                          ],
                        ),
                      ),
                    ),
                    Flexible(
                      flex: 1,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5, 15, 20, 0),
                        child: TextFormField(
                          //expands: true,
                          controller: stockControl,
                          decoration: const InputDecoration(
                            border: OutlineInputBorder(),
                            labelText: 'Stock',
                          ),
                          validator: (String? value) {
                            return (value == null || value.isEmpty)
                                ? 'Can\'t be empty!'
                                : null;
                          },
                          keyboardType: TextInputType.number,
                          inputFormatters: <TextInputFormatter>[
                            FilteringTextInputFormatter.allow(
                                RegExp(r'(^[0-9]*$)'))
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.fromLTRB(20, 15, 20, 15),
                  child: TextFormField(
                    maxLines: 4,
                    controller: descControl,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      labelText: 'Description',
                    ),
                    validator: (String? value) {
                      return (value == null || value.isEmpty)
                          ? 'Can\'t be empty!'
                          : null;
                    },
                  ),
                ),
                FilledButton.tonal(
                  child: const Text(
                    'Confirm',
                    style: TextStyle(fontSize: 18),
                  ),
                  onPressed: () async {
                    if (_formKey.currentState!.validate()) {
                      if (!widget.isEdit) {
                        await sendFoodCardData(FoodCardData(
                            itemId: 0,
                            name: nameControl.text,
                            description: descControl.text,
                            rating: 0,
                            price: double.parse(priceControl.text),
                            timesOrdered: 0,
                            inStock: int.parse(stockControl.text),
                            image: '0'));
                        Navigator.pop(context);
                        nameControl.text = '';
                        descControl.text = '';
                        priceControl.text = '';
                        stockControl.text = '';
                      } else {
                        await updateFoodCardData(
                            FoodCardData(
                                itemId: widget.cardData.itemId,
                                name: nameControl.text,
                                description: descControl.text,
                                rating: widget.cardData.rating,
                                price: double.parse(priceControl.text),
                                timesOrdered: widget.cardData.timesOrdered,
                                inStock: int.parse(stockControl.text),
                                image: '0'), (errMsg) {
                          if (errMsg == 'pop') {
                            Navigator.of(context).pop();
                          } else {
                            showDialog(
                                context: context,
                                builder: (BuildContext context) {
                                  return AlertDialog(
                                    title: const Text("Error"),
                                    content: Text(errMsg),
                                    actions: <Widget>[
                                      TextButton(
                                        child: const Text('OK'),
                                        onPressed: () {
                                          Navigator.of(context).pop();
                                        },
                                      ),
                                    ],
                                  );
                                });
                          }
                        });
                      }

                      widget.updateList();
                    }
                    ;
                  },
                ),
                const SizedBox(
                  height: 10,
                )
              ],
            ),
          ),
        ),
      ),
    );

    ;
  }
}
