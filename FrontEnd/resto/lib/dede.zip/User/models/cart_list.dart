import '../models/food.dart';
import 'package:flutter/material.dart';

class CartList extends ChangeNotifier {
  static CartList MyCartList = CartList();

  List<Food> _items = [];
  double _price = 0.0;
  double _oldPrice = 0.0;
  double? _descount;
  String coupon = "Resto";
  bool? couponstate;

  void add(Food item) {
    int len = _items.length;
    for (Food x in _items) {
      if (item.name == x.name &&
          item.description == x.description &&
          item.rating == x.rating) {
        x.quantity += item.quantity;
        return;
      }
    }
    if (len == _items.length) {
      _items.add(item);
    }
    print(5);
    notifyListeners();
  }

  void remove(Food item) {
    _items.remove(item);
    notifyListeners();
  }

  int get count {
    return _items.length;
  }

  double get totalPrice {
    _price = 0.0;
    for (Food x in _items) {
      _price += x.price * x.quantity;
    }
    if (couponstate == true && _descount != null) {
      _price = _price - (_price / _descount!);
    }
    return _price;
  }

  double get oldTotalPrice {
    _oldPrice = 0.0;
    for (Food x in _items) {
      _oldPrice += x.price * x.quantity;
    }
    return _oldPrice;
  }

  List<Food> get items {
    return _items;
  }

  clear() {
    _items.clear();
    _price = 0.0;
  }

  updatePrice(double descount) {
    _descount = descount;
    couponstate = true;
  }
}
