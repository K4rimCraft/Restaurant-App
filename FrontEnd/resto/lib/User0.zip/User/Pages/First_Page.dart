// import 'package:curved_navigation_bar/curved_navigation_bar.dart';
// import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
// import 'Booking/Booking.dart';
// import '../Pages/MainPage.dart';
// import '../Pages/Menu.dart';
// import 'Settings/Settings.dart';
// import '../theme/app_color.dart';

// class FirstPage extends StatefulWidget {
//   int selectedPage;
//   int sliding;
//   FirstPage({super.key, required this.selectedPage, required this.sliding});

//   @override
//   State<FirstPage> createState() => _FirstPageState();
// }

// class _FirstPageState extends State<FirstPage> {
//   @override
//   Widget build(BuildContext context) {
//     return 
//   }
// }
