import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '/User/Pages/First_Page.dart';
import '/User/Pages/Cart.dart';
import '/User/theme/app_color.dart';

class UserInterface extends StatefulWidget {
  int selectedPage;
  int sliding;
  UserInterface({super.key, required this.selectedPage, required this.sliding});
  @override
  State<UserInterface> createState() => _UserInterfaceState();
}

class _UserInterfaceState extends State<UserInterface> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => Cart(),
      child:
          FirstPage(selectedPage: widget.selectedPage, sliding: widget.sliding),
    );
  }
}
